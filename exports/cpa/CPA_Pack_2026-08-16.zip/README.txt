Sales Tax Compliance — CPA Export Pack
Generated: 2026-08-16
Period: all

DISCLAIMER: This is a monitoring and research aid assembled from
Amazon SP-API, Shopify API, and configured state rules. It is NOT
legal, tax, or CPA advice. Rules change. Verify against primary
state DOR authority and Seller Central before acting.

Contents:
  economic_nexus_audit.csv    — Per-state threshold analysis with marketplace rules
  registration_triage.csv     — Triage buckets for CPA discussion
  inventory_presence.csv      — FBA inventory presence by state/month
  sales_by_state_detail.csv   — All sales records (channel normalized)
  nexus_status_snapshot.csv   — Current nexus flags + registration status
  franchise_flags_open.csv    — Open franchise/entity tax flags

How to match Seller Central:
  - Orders reports ≈ Business Reports by order date (gross, pre-refund)
  - Settlement reports ≈ Payments → Settlement Period (cash/deposit view)
  - Custom Combined Tax ≈ tax jurisdiction detail, not bank deposits
  - Agent liability uses sales/nexus rules; settlements validate Amazon completeness
